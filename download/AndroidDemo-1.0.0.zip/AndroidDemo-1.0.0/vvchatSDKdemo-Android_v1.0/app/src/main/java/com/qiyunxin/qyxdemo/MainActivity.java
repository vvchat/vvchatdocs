package com.qiyunxin.qyxdemo;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.qiyunxin.qyxsdk.sdk.PicktalkShareRequset;
import com.qiyunxin.qyxsdk.sdk.SDKUtils;

public class MainActivity extends AppCompatActivity {

    // app_id
    private static String appId = "test";
    // app key
    private static String appKey = "123456";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    protected void initView() {
        findViewById(R.id.payBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toPay();
            }
        });
        findViewById(R.id.loginBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toLogin();
            }
        });
        findViewById(R.id.shareBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toShare();
            }
        });
    }

    private void toShare() {
        PicktalkShareRequset mPicktalkShareRequset = new PicktalkShareRequset();
        mPicktalkShareRequset.setShare_url("https://book.douban.com/subject/6920082/");
        mPicktalkShareRequset.setShare_title("来自分享");
        mPicktalkShareRequset.setThumb_url("http://img.zcool.cn/community/0142135541fe180000019ae9b8cf86.jpg@1280w_1l_2o_100sh.png");
        mPicktalkShareRequset.setApp_Id(appId);
        mPicktalkShareRequset.setSub_title("此内容安全有效，请点击从查看具体");
        SDKUtils.SendRequest(mPicktalkShareRequset,this);
    }

    /**
     * 企云信支付
     */
    private void toPay(){
        Intent intent = new Intent(MainActivity.this,PayActivity.class);
        intent.putExtra("app_id",appId);
        intent.putExtra("app_key",appKey);
        startActivity(intent);
    }

    /**
     * 企云信登录
     */
    private void toLogin(){
        Intent intent = new Intent(MainActivity.this,ThirdLoginActivity.class);
        intent.putExtra("app_id",appId);
        intent.putExtra("app_key",appKey);
        startActivity(intent);
//        LoginRequest loginRequest = new LoginRequest();
//        loginRequest.setAppId(appId);
//        loginRequest.setScope("snsapi_userinfo");
//        loginRequest.setState("test");
//        SDKUtils.SendRequest(loginRequest,this);
    }

}
