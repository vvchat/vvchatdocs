package com.qiyunxin.qyxdemo.utils;

import android.text.TextUtils;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @Author: SL
 * @Date: 2017/12/26 19:06
 * @CopyRight: http://www.qiyunxin.com
 * @Parameter: TODO
 * @Function: TODO
 */
public class Sign {


    public static Map<String, String> buildOrderParamMap(UnifiedorderModel model) {
        Map<String, String> keyValues = new HashMap<String, String>();
        keyValues.put("app_id", model.getAppId());
        keyValues.put("store_no", model.getStoreNo());
        keyValues.put("out_trade_no", model.getOutTradeNo());
        keyValues.put("nonce_str", model.getNonceStr());
        keyValues.put("sign_type", model.getSignType());
        keyValues.put("notify_url", model.getNotifyUrl());
        keyValues.put("amount", model.getAmount()+"");
        keyValues.put("title", model.getTitle());
        keyValues.put("remark", model.getRemark());
        keyValues.put("scene_type", model.getSceneType());
        if ( model.getSign()!=null && !model.getSign().equals("")) {
            keyValues.put("sign", model.getSign());
        }

        return keyValues;
    }

    /**
     * 获取千米字符串
     *
     * @param map 支付订单参数
     * @return
     */
    public static String getSignStr(Map<String, String> map) {
        Set<String> keys = map.keySet();
        String[] keyArray = keys.toArray(new String[keys.size()]);
        Arrays.sort(keyArray);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < keyArray.length - 1; i++) {
            String key = keyArray[i];
            String value = map.get(key);
            if (value==null || value.equals("")) {
                continue;
            }
            sb.append(buildKeyValue(key, value, true));
            sb.append("&");
        }

        String tailKey = keyArray[keyArray.length - 1];
        String tailValue = map.get(tailKey);
        if (tailValue!=null && !tailValue.equals("")){
            sb.append(buildKeyValue(tailKey, tailValue, true));
            return sb.toString();
        }else{
            return sb.toString().substring(0,sb.toString().length()-1);
        }


    }
    /**
     * 拼接键值对
     *
     * @param key
     * @param value
     * @param isEncode
     * @return
     */
    private static String buildKeyValue(String key, String value, boolean isEncode) {
        StringBuilder sb = new StringBuilder();
        sb.append(key);
        sb.append("=");
        if (false) {
            try {
                sb.append(URLEncoder.encode(value, "UTF-8"));
            } catch (UnsupportedEncodingException e) {
                sb.append(value);
            }
        } else {
            sb.append(value);
        }
        return sb.toString();
    }

    public static String md5(String string) {
        if (TextUtils.isEmpty(string)) {
            return "";
        }
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
            byte[] bytes = md5.digest(string.getBytes());
            String result = "";
            for (byte b : bytes) {
                String temp = Integer.toHexString(b & 0xff);
                if (temp.length() == 1) {
                    temp = "0" + temp;
                }
                result += temp;
            }
            return result;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

}
