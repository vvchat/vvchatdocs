package com.qiyunxin.qyxdemo;

import android.app.Activity;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.qiyunxin.qyxdemo.utils.HttpRequest;
import com.qiyunxin.qyxdemo.utils.Sign;
import com.qiyunxin.qyxdemo.utils.UnifiedorderModel;
import com.qiyunxin.qyxsdk.sdk.PayRequest;
import com.qiyunxin.qyxsdk.sdk.SDKUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Random;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

/**
 * 支付相关操作Activity
 */
public class PayActivity extends Activity {

    // 店铺编号
    private static String storeNo = "s1234";


    private EditText order_edit;
    private EditText amount_edit;
    private String appId;
    private String appKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay);
        initView();
        appId = this.getIntent().getStringExtra("app_id");
        appKey = this.getIntent().getStringExtra("app_key");
    }

    protected void initView() {
        order_edit = (EditText) findViewById(R.id.order_edit);
        amount_edit = (EditText) findViewById(R.id.amount_edit);
        findViewById(R.id.payBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /**
                 * 调用统一下单接口
                 */
                UnifiedorderModel model = new UnifiedorderModel();
                model.setAppId(appId);
                model.setAmount(Integer.parseInt(amount_edit.getText().toString()));
                model.setNonceStr(getRandomString(8));
                model.setNotifyUrl("http://baidu.com");
                model.setOutTradeNo(order_edit.getText().toString());
                model.setTitle("测试");
                model.setSceneType("APP");
                model.setStoreNo(storeNo);
                model.setSignType("MD5");
                model.setSign(getSign(model));
                HttpRequest.requestUnifiedorder(model, new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                        Looper.prepare();
                        Toast.makeText(PayActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        Looper.loop();
                    }

                    @Override
                    public void onResponse(Call call, final Response response) throws IOException {
                        Log.i("Response:", response.toString());
                        final String result = response.body().string();
                        if (response.isSuccessful()) {
                            PayActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Log.i("result:", result);
                                    try {
                                        JSONObject jsonObject = new JSONObject(result);
                                        PayRequest payRequest = new PayRequest();
                                        payRequest.setImprestCode(jsonObject.getString("imprest_code"));
                                        payRequest.setAppId(appId);
                                        SDKUtils.SendRequest(payRequest, PayActivity.this);
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                }
                            });
                        } else {
                            Looper.prepare();
                            Toast.makeText(PayActivity.this, result, Toast.LENGTH_LONG).show();
                            Looper.loop();
                        }
                    }
                });

            }
        });
    }

    /**
     * 获取签名字符串
     * @param model
     * @return
     */
    private String getSign(UnifiedorderModel model) {
        String signStr = Sign.getSignStr(Sign.buildOrderParamMap(model));
        signStr = signStr + "&key=" + appKey;
        Log.i("signStr:", signStr);
        return Sign.md5(signStr).toUpperCase();
    }

    /**
     * 获取随机字符串
     * @param length
     * @return
     */
    public static String getRandomString(int length) {
        StringBuffer buffer = new StringBuffer("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
        StringBuffer sb = new StringBuffer();
        Random random = new Random();
        int range = buffer.length();
        for (int i = 0; i < length; i++) {
            sb.append(buffer.charAt(random.nextInt(range)));
        }
        return sb.toString();
    }
}
