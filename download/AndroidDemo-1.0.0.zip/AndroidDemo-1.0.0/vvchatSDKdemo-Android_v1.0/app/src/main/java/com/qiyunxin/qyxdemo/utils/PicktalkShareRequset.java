package com.qiyunxin.qyxsdk.sdk;

/**
 * Created by Administrator on 2018/3/22 0022.
 */

public class PicktalkShareRequset extends QYXRequest {

    //app id
    private String app_Id;
    private String share_url;//分享链接
    private String share_title;//头部
    private String sub_title;//预览内容
    private String thumb_url;//预览图


    @Override
    public String getAppId() {
        return app_Id;
    }

    public  String getApp_Id() {
        return app_Id;
    }public void   setApp_Id(String app_Id) {
        this.app_Id = app_Id;
    }public String getShare_url() {
        return share_url;
    }public void   setShare_url(String share_url) {
        this.share_url = share_url;
    }public String getShare_title() {
        return share_title;
    }public void   setShare_title(String share_title) {
        this.share_title = share_title;
    }public String getSub_title() {
        return sub_title;
    }public void   setSub_title(String sub_title) {
        this.sub_title = sub_title;
    }public String getThumb_url() {
        return thumb_url;
    }public void   setThumb_url(String thumb_url) {
        this.thumb_url = thumb_url;
    }
}
